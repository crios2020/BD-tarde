drop database if exists negocio;
create database negocio;
use negocio;

create table clientes (
codigo integer auto_increment,
nombre varchar(20) not null,
apellido varchar(20) not null,
cuit char(13),
direccion varchar(50),
comentarios varchar(140),
primary key (codigo)
);

create table facturas(
letra char(1),
numero integer,
fecha date,
monto double,
primary key (letra,numero)
);

create table articulos(
codigo integer auto_increment,
nombre varchar(50),
precio double,
stock integer,
primary key (codigo)
);

insert into clientes (nombre,apellido,cuit,direccion) values ('juan','perez','xxxxx','peru 323');
insert into clientes (nombre,apellido,cuit,direccion) values ('diego','torres','xxxxx','chile 320');
insert into clientes (nombre,apellido,cuit,direccion) values ('laura','gomez','xxxxx','san juan 420');
insert into clientes (nombre,apellido,cuit,direccion) values ('mario','lopez','xxxxx','lavalle 770');
insert into clientes (nombre,apellido,cuit,direccion) values ('dario','sanchez','xxxxx','mexico 150');

insert into articulos values (1,'destornillador',25,50);
insert into articulos values (2,'pinza',35,22);
insert into articulos values (3,'martillo',15,28);
insert into articulos values (4,'maza',35,18);
insert into articulos values (5,'valde',55,13);

insert into facturas values ('a',0001,'2011/10/18',500);
insert into facturas values ('a',0002,'2011/10/18',2500);
insert into facturas values ('b',0003,'2011/10/18',320);
insert into facturas values ('b',0004,'2011/10/18',120);
insert into facturas values ('b',0005,'2011/10/18',560);
-- inserto un registro con la fecha actual
insert into facturas values ('c',0006,curdate(),300);

insert into clientes (nombre,apellido,cuit,direccion) values ('maria','fernandez','xxxxx','');
insert into clientes (nombre,apellido,cuit,direccion) values ('gustavo','ramirez','xxxxx',null);


insert into facturas values ('f',0006,curdate(),300);
insert into facturas values ('f',0007,curdate(),400);

insert into clientes (nombre,apellido,cuit,direccion) values ('jose','benuto','3647493','loria 940');

insert into facturas (letra,numero,fecha,monto) values ('a',1001,'2012/10/25',350);
insert into facturas (letra,numero,fecha,monto) values ('a',1002,curdate(),540);

insert into articulos (codigo,nombre,precio,stock) values (110,'destornillador',30,100);
insert into articulos (codigo,nombre,precio,stock) values (111,'martillo',40*1.21,50);

insert into clientes (nombre,apellido,direccion) values ('Andrea','Abate','Laprida 648');
insert into clientes (apellido,nombre) values ('Stuart','Jhon');
insert into clientes values(null,'Laura','Georgeff','56565','Berutti 2589','');
insert into clientes (codigo,nombre,apellido,cuit,direccion) values (null,'jose','sanchez','xxxxx','chile 150');
insert into clientes values (null,'marta','martinez','xxxxx','florida 150','');
insert into clientes (nombre,apellido,cuit,direccion) values ('carlos','flores','xxxxx','bolivar 150');
insert into clientes values (20,'Romeo','Lopez','34343434','Anchorena 950','');
insert into clientes (nombre,apellido,cuit,direccion) values ('Florencia','Salinas','82828282','W.Morris 3420');
insert into clientes (apellido,nombre,direccion) values ('Ana','Salone',null);

show tables;
describe clientes;
describe articulos;
describe facturas;
select * from clientes;
select * from articulos;
select * from facturas;

-- Agregamos en la tabla facturas el campo codigoCliente
alter table facturas add codigoCliente int not null;

set sql_safe_updates=0;
update facturas set codigoCliente=1 where numero=1;
update facturas set codigoCliente=2 where numero=2;
update facturas set codigoCliente=2 where numero=3;
update facturas set codigoCliente=4 where numero=4;
update facturas set codigoCliente=5 where numero>=5;

insert into facturas values ('a',1055,curdate(),6000,150);
select * from clientes where codigo=150;
delete from facturas where letra='a' and numero=1055;

-- agregar la restricción de clave foranea
alter table facturas
	add constraint FK_Facturas_CodigoCliente
    foreign key(codigoCliente)
    references clientes(codigo);

-- consulta del producto cartesiano
select * from clientes, facturas;
select count(*) cantidad from clientes;						-- 17
select count(*) cantidad from facturas;						-- 10
select count(*) cantidad from clientes, facturas;			-- 170

-- consulta del producto relacionado
select * from clientes, facturas where clientes.codigo=facturas.codigoCliente;
select * from clientes c join facturas f where c.codigo=f.codigoCliente;
-- Uso join
select * from clientes c join facturas f on c.codigo=f.codigoCliente;

-- Quienes(nombre, apellido) compraron en el dia de hoy?
select distinct c.codigo, c.nombre, c.apellido 
	from clientes c join facturas f on c.codigo=f.codigoCliente 
    where fecha=curdate();

select * from clientes;
insert into facturas values ('a',6556,curdate(),8000,1);
-- Que facturas realizo Juan Perez
select letra,numero,fecha,monto 
	from clientes c join facturas f on c.codigo=f.codigoCliente 
    where nombre='Juan' and apellido='Perez';

create table detalles(
	letra char(1),
    numero int,
    codigo int,
    cantidad int,
    primary key(letra,numero,codigo)
);

-- creamos la clave foranea detalles facturas
alter table detalles 
	add constraint FK_detalles_facturas
    foreign key(letra,numero)
    references facturas(letra,numero);

-- creamos la clave foranea detalles articulos
alter table detalles
	add constraint FK_detalles_articulos
    foreign key(codigo)
    references articulos(codigo);
    
insert into detalles values ('a',1,1,3);
insert into detalles values ('a',1,2,1);
insert into detalles values ('a',2,4,30);

-- consulta del producto cartesiano
select * from clientes, facturas, detalles, articulos;
select count(*) cantidad from clientes;						-- 17
select count(*) cantidad from facturas;						-- 11
select count(*) cantidad from detalles;						--  3
select count(*) cantidad from articulos;					--  7
select 17*11*3*7 cantidad;									-- 3927

-- consulta del producto relacionado
select * from clientes c join facturas f on c.codigo=f.codigoCliente
		join detalles d on f.letra=d.letra and f.numero=d.numero
        join articulos a on d.codigo=a.codigo;

-- Que articulos compro juan perez?
select a.codigo, a.nombre, a.precio, a.stock
	from clientes c join facturas f on c.codigo=f.codigoCliente
		join detalles d on f.letra=d.letra and f.numero=d.numero
        join articulos a on d.codigo=a.codigo
        where c.nombre='Juan' and c.apellido='Perez';
    
    