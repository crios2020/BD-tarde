-- Uso de JOIN

-- Usando la base de datos negocio2 (solo tablas clientes y facturas).

-- 1-	Informar que clientes (codigo, nombre, apellido) han comprado en el día de hoy.
-- 2-	Informar la suma de los montos de cada cliente (código,nombre,apellido,total_comprado).
-- 3-	Informar cual es el cliente que más ha comprado (codigo, nombre, apellido).
-- 4-	Informar la cantidad de facturas de cada cliente (codigo, nombre, apellido,cantidad_facturas).
-- 5-	Informar quienes compraron el primer día de ventas (codigo, nombre, apellido).
-- 6-	Informar que compro el cliente Juan Perez (letra,nro,fecha,monto).


