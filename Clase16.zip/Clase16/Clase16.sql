/*
		DBA Database Administrator
*/

drop database if exists reservas;
create database reservas;
use reservas;

create table Habitaciones(
	habitacion_numero int primary key,
    precio_por_noche decimal(8,2) not null,
    piso int not null,
    max_personas tinyint not null,
    tiene_cama_bebe tinyint not null,
    tiene_ducha tinyint not null,
    tiene_bano tinyint not null,
    tiene_balcon tinyint not null
);

create table Huespedes(
	huesped_id int primary key auto_increment,
    nombres varchar(45) not null,
    apellidos varchar(45) not null,
    telefono double not null,
    correo varchar(45) not null,
    direccion varchar(45) not null,
    ciudad varchar(45) not null,
    pais varchar(45) not null
);

create table Reservas(
	reserva_id int primary key auto_increment,
    inicio_fecha datetime not null,
    fin_fecha datetime not null,
    habitacion int not null,
    huesped int not null
    -- foreign key(habitacion) references Habitaciones(habitacion_numero),
    -- foreign key(huesped) references Huespedes(huesped_id)
);

alter table Reservas 
	add constraint FK_ReservasHabitaciones
    foreign key(habitacion)
    references Habitaciones(habitacion_numero);

alter table Reservas
	add constraint FK_ReservasHuespedes
    foreign key(huesped)
    references Huespedes(huesped_id);
    
describe Habitaciones;
insert into Habitaciones values (201,9000,2,5,0,1,1,1);

describe Huespedes;
insert into Huespedes values 
	(null,'Beatriz','Anaya',0303456,'beaanaya@gmail.com','viel 123','CABA','ARGENTINA');

describe Reservas;
insert into Reservas values
	(null,curdate(),'2022/12/20',201,1);
    
select * from Habitaciones ha join Reservas r on ha.habitacion_numero=r.habitacion
		join Huespedes hu on r.huesped=hu.huesped_id;

