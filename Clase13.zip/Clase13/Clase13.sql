drop database if exists negocio;
create database negocio;
use negocio;

create table clientes (
codigo integer auto_increment,
nombre varchar(20) not null,
apellido varchar(20) not null,
cuit char(13),
direccion varchar(50),
comentarios varchar(140),
primary key (codigo)
);

create table facturas(
letra char(1),
numero integer,
fecha date,
monto double,
primary key (letra,numero)
);

create table articulos(
codigo integer auto_increment,
nombre varchar(50),
precio double,
stock integer,
primary key (codigo)
);

insert into clientes (nombre,apellido,cuit,direccion) values ('juan','perez','xxxxx','peru 323');
insert into clientes (nombre,apellido,cuit,direccion) values ('diego','torres','xxxxx','chile 320');
insert into clientes (nombre,apellido,cuit,direccion) values ('laura','gomez','xxxxx','san juan 420');
insert into clientes (nombre,apellido,cuit,direccion) values ('mario','lopez','xxxxx','lavalle 770');
insert into clientes (nombre,apellido,cuit,direccion) values ('dario','sanchez','xxxxx','mexico 150');

insert into articulos values (1,'destornillador',25,50);
insert into articulos values (2,'pinza',35,22);
insert into articulos values (3,'martillo',15,28);
insert into articulos values (4,'maza',35,18);
insert into articulos values (5,'valde',55,13);

insert into facturas values ('a',0001,'2011/10/18',500);
insert into facturas values ('a',0002,'2011/10/18',2500);
insert into facturas values ('b',0003,'2011/10/18',320);
insert into facturas values ('b',0004,'2011/10/18',120);
insert into facturas values ('b',0005,'2011/10/18',560);
-- inserto un registro con la fecha actual
insert into facturas values ('c',0006,curdate(),300);

insert into clientes (nombre,apellido,cuit,direccion) values ('maria','fernandez','xxxxx','');
insert into clientes (nombre,apellido,cuit,direccion) values ('gustavo','ramirez','xxxxx',null);


insert into facturas values ('f',0006,curdate(),300);
insert into facturas values ('f',0007,curdate(),400);

insert into clientes (nombre,apellido,cuit,direccion) values ('jose','benuto','3647493','loria 940');

insert into facturas (letra,numero,fecha,monto) values ('a',1001,'2012/10/25',350);
insert into facturas (letra,numero,fecha,monto) values ('a',1002,curdate(),540);

insert into articulos (codigo,nombre,precio,stock) values (110,'destornillador',30,100);
insert into articulos (codigo,nombre,precio,stock) values (111,'martillo',40*1.21,50);

insert into clientes (nombre,apellido,direccion) values ('Andrea','Abate','Laprida 648');
insert into clientes (apellido,nombre) values ('Stuart','Jhon');
insert into clientes values(null,'Laura','Georgeff','56565','Berutti 2589','');
insert into clientes (codigo,nombre,apellido,cuit,direccion) values (null,'jose','sanchez','xxxxx','chile 150');
insert into clientes values (null,'marta','martinez','xxxxx','florida 150','');
insert into clientes (nombre,apellido,cuit,direccion) values ('carlos','flores','xxxxx','bolivar 150');
insert into clientes values (20,'Romeo','Lopez','34343434','Anchorena 950','');
insert into clientes (nombre,apellido,cuit,direccion) values ('Florencia','Salinas','82828282','W.Morris 3420');
insert into clientes (apellido,nombre,direccion) values ('Ana','Salone',null);

-- Ampliación de la base Negocio, se agregan relaciones y tabla detalles
-- Requiere tener la base negocio

use negocio;

-- declaro la Foreign Key FK
alter table facturas add codigocliente integer not null;


-- cargamos todas las facturas a los clientes 1,2,3 y 4 para despues poder crear la restriccion fk
set sql_safe_updates=0;
update facturas set codigocliente=1 where letra='a';
update facturas set codigocliente=2 where letra='b';
update facturas set codigocliente=3 where letra='c';
update facturas set codigocliente=4 where letra='f';

alter table facturas
add constraint FK_facturas_codcli
foreign key (codigocliente)
references clientes(codigo)
on delete cascade;

insert into facturas values ('a',1050,curdate(),250,1);

-- ------------------------
-- Agrego la tabla detalles
-- ------------------------

create table detalles(
letra char(1) not null,
numero int not null,
codigo int not null,
cantidad int unsigned not null,
primary key(letra,numero,codigo)
);

-- ------------------------
-- inserto detalles de las facturas
-- ------------------------

insert into detalles values('a',1,3,10);
insert into detalles values('a',1,1,3);
insert into detalles values('a',1,5,3);
insert into detalles values('a',2,3,10);
insert into detalles values('b',3,3,10);

alter table detalles
add constraint FK_facturas_letra_numero
foreign key (letra,numero)
references facturas(letra,numero)
on delete cascade;

alter table detalles
add constraint FK_detalles_articilos
foreign key (codigo)
references articulos(codigo);


show tables;

-- Uso de JOIN

-- Usando la base de datos negocio2 (solo tablas clientes y facturas).

-- 1-	Informar que clientes (codigo, nombre, apellido) han comprado en el día de hoy.
select distinct c.codigo, c.nombre, c.apellido 
	from clientes c join facturas f on c.codigo=f.codigoCliente
	where fecha=curdate();

-- 2-	Informar la suma de los montos de cada cliente (código,nombre,apellido,total_comprado).
select c.codigo, c.nombre, c.apellido, sum(monto) total 
	from clientes c join facturas f on c.codigo=f.codigoCliente
    group by c.codigo;
    
-- 3-	Informar cual es el cliente que más ha comprado (codigo, nombre, apellido).
select c.codigo, c.nombre, c.apellido, sum(monto) total 
	from clientes c join facturas f on c.codigo=f.codigoCliente
    group by c.codigo 
    order by total desc
    limit 1;

-- 4-	Informar la cantidad de facturas de cada cliente (codigo, nombre, apellido,cantidad_facturas).
select c.codigo, c.nombre, c.apellido, count(*) cantidad
	from clientes c join facturas f on c.codigo=f.codigoCliente
    group by c.codigo;
    
-- 5-	Informar quienes compraron el primer día de ventas (codigo, nombre, apellido).
select distinct c.codigo, c.nombre, c.apellido, fecha
	from clientes c join facturas f on c.codigo=f.codigoCliente
    where fecha=(select min(fecha) from facturas);
    
-- 6-	Informar que compro el cliente Juan Perez (letra,nro,fecha,monto).
select letra,numero,fecha,monto
	from clientes c join facturas f on c.codigo=f.codigoCliente
    where nombre='Juan' and apellido='Perez';

-- Que articulos compro juan perez?
select a.codigo, a.nombre, a.precio, a.stock
	from clientes c join facturas f on c.codigo=f.codigoCliente
		join detalles d on f.letra=d.letra and f.numero=d.numero
        join articulos a on d.codigo=a.codigo
        where c.nombre='Juan' and c.apellido='Perez';

-- Laboratorio 9
-- Usando la base de datos negocio2 (usando todas las tablas).

-- 1- Informar quienes (nombre,apellido) compraron 'lamparas'.
select c.codigo, c.nombre, c.apellido
	from clientes c join facturas f on c.codigo=f.codigoCliente
	join detalles d on f.letra=d.letra and f.numero=d.numero
    join articulos a on d.codigo=a.codigo
    where a.nombre like '%lampara%';

select * from articulos;
describe articulos;
insert into articulos (nombre,precio,stock) values
	('Lampara led 5W',500,40),
    ('Lampara led 7W',600,30),
    ('Lampara led 9W',700,20);
select * from clientes;
insert into clientes (nombre,apellido,cuit,direccion) values
	('Josefina','Riera','43434343','Larrea 234');
insert into facturas values ('a',1068,curdate(),9000,23);
describe detalles;
select * from detalles;
insert into detalles values 
	('a',1068,112,2);
insert into detalles values 
	('a',1068,2,2);
insert into detalles values
	('b',3,113,3);
insert into detalles values
	('b',3,3,3);
insert into detalles values
	('f',7,113,3);
insert into detalles values
	('f',7,1,3);
insert into detalles values
	('f',7,4,5);
    

-- 2- Informar que articulos compro 'Juan Perez'.
select a.codigo, a.nombre, a.precio, a.stock
	from clientes c join facturas f on c.codigo=f.codigoCliente
		join detalles d on f.letra=d.letra and f.numero=d.numero
        join articulos a on d.codigo=a.codigo
        where c.nombre='Juan' and c.apellido='Perez';

-- 3- Informar cuantas lamparas se vendieron.
select sum(d.cantidad) cantidad
	from clientes c join facturas f on c.codigo=f.codigoCliente
		join detalles d on f.letra=d.letra and f.numero=d.numero
        join articulos a on d.codigo=a.codigo
		where a.nombre like '%lampara%';
        
-- 4- Informar cuantas unidades se vendieron en total en cada articulo.
select a.codigo, a.nombre, sum(d.cantidad) cantidad
	from detalles d
    join articulos a on d.codigo=a.codigo
    group by a.nombre;
    
-- 5- Informar la lista de artículos vendidos el día de hoy.
select a.codigo, a.nombre, a.precio, a.stock
	from facturas f join detalles d on f.letra=d.letra and f.numero=d.numero
	join articulos a on d.codigo=a.codigo
    where fecha=curdate();
    
-- 6- Informar la lista de artículos vendidos en este mes.
select a.codigo, a.nombre, a.precio, a.stock
	from facturas f join detalles d on f.letra=d.letra and f.numero=d.numero
	join articulos a on d.codigo=a.codigo
    where month(fecha)=month(curdate())
	and year(fecha)=year(curdate());
    
-- 7- Informar la lista de artículos vendidos en este año y la cantidad vendida.
select a.codigo, a.nombre, a.precio, a.stock, sum(d.cantidad) cantidad
	from facturas f join detalles d on f.letra=d.letra and f.numero=d.numero
	join articulos a on d.codigo=a.codigo
    where year(fecha)=year(curdate())
    group by a.codigo;

-- -------------    -------------------     -------------     
-- - libros    -    - prestamos       -     - socios    -    
-- -------------    -------------------     -------------     
-- - codigo PK -    - documento   PK  -     - documento -
-- - titulo    -    - codigolibro PK  -     - nombre    -
-- - autor     -    - fechaprestamo   -     - domicilio -
-- -------------    - fechadevolucion -     -------------
--                  -------------------                

drop database if exists libros;
create database libros;
use libros;

drop table if exists libros;
create table libros(
  codigo int unsigned auto_increment,
  titulo varchar(40) not null,
  autor varchar(20) default 'Desconocido',
  primary key (codigo)
);

drop table if exists socios;
create table socios(
  documento char(8) not null,
  nombre varchar(30),
  domicilio varchar(30),
  primary key (documento)
);

drop table if exists prestamos;
create table prestamos(
  documento char(8) not null,
  codigolibro int unsigned,
  fechaprestamo date not null,
  fechadevolucion date,
  primary key (codigolibro,fechaprestamo)
);

insert into socios values('22333444','Juan Perez','Colon 345');
insert into socios values('23333444','Luis Lopez','Caseros 940');
insert into socios values('25333444','Ana Herrero','Sucre 120');

insert into libros values(1,'Manual de 2º grado','Molina Manuel');
insert into libros values(25,'Aprenda PHP','Oscar Mendez');
insert into libros values(42,'Martin Fierro','Jose Hernandez');

insert into prestamos values('22333444',1,'2006-08-10','2006-08-12');
insert into prestamos values('22333444',1,'2006-08-15',null);
insert into prestamos values('25333444',25,'2006-08-10','2006-08-13');
insert into prestamos values('25333444',42,'2006-08-10',null);
insert into prestamos values('25333444',25,'2006-08-15',null);
insert into prestamos values('30333444',42,'2006-08-02','2006-08-05');
insert into prestamos values('25333444',2,'2006-08-02','2006-08-05');


-- Pendiente

-- Usando la base de datos Libros responder la siguientes consultas.

-- 1- Que libros (codigo,titulo,autor) se le prestaron a cada socio.
-- 2- Lista de socios (documento,nombre,domicilio) que se le presto libros de 'java' (like '%java%')
-- 3- Lista de libros (codigo,titulo,autor) que no fueron devueltos (fechadevolucion is null)
-- 4- Lista de socios (documento,nombre,domicilio) que tienen libros sin devolver.
-- 5- Lista de socios (documento,nombre,domicilio) que tienen libros sin devolver y cuales son los libros.
-- 6- Cantidad de libros sin devolver.
-- 7- Lista de libros que fueron prestados el día de hoy.
-- 8- Cantidad de libros que se prestaron en este mes.
-- 9- Cantidad de libros que fueron prestados en este mes.
-- 10-Cantidad de socion que se le prestaron libres en este mes.
