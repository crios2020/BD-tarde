drop database if exists negocio;
create database negocio;
use negocio;

create table clientes (
codigo integer auto_increment,
nombre varchar(20) not null,
apellido varchar(20) not null,
cuit char(13),
direccion varchar(50),
comentarios varchar(140),
primary key (codigo)
);

create table facturas(
letra char(1),
numero integer,
fecha date,
monto double,
primary key (letra,numero)
);

create table articulos(
codigo integer auto_increment,
nombre varchar(50),
precio double,
stock integer,
primary key (codigo)
);

insert into clientes (nombre,apellido,cuit,direccion) values ('juan','perez','xxxxx','peru 323');
insert into clientes (nombre,apellido,cuit,direccion) values ('diego','torres','xxxxx','chile 320');
insert into clientes (nombre,apellido,cuit,direccion) values ('laura','gomez','xxxxx','san juan 420');
insert into clientes (nombre,apellido,cuit,direccion) values ('mario','lopez','xxxxx','lavalle 770');
insert into clientes (nombre,apellido,cuit,direccion) values ('dario','sanchez','xxxxx','mexico 150');

insert into articulos values (1,'destornillador',25,50);
insert into articulos values (2,'pinza',35,22);
insert into articulos values (3,'martillo',15,28);
insert into articulos values (4,'maza',35,18);
insert into articulos values (5,'valde',55,13);

insert into facturas values ('a',0001,'2011/10/18',500);
insert into facturas values ('a',0002,'2011/10/18',2500);
insert into facturas values ('b',0003,'2011/10/18',320);
insert into facturas values ('b',0004,'2011/10/18',120);
insert into facturas values ('b',0005,'2011/10/18',560);
-- inserto un registro con la fecha actual
insert into facturas values ('c',0006,curdate(),300);

insert into clientes (nombre,apellido,cuit,direccion) values ('maria','fernandez','xxxxx','');
insert into clientes (nombre,apellido,cuit,direccion) values ('gustavo','ramirez','xxxxx',null);


insert into facturas values ('f',0006,curdate(),300);
insert into facturas values ('f',0007,curdate(),400);

insert into clientes (nombre,apellido,cuit,direccion) values ('jose','benuto','3647493','loria 940');

insert into facturas (letra,numero,fecha,monto) values ('a',1001,'2012/10/25',350);
insert into facturas (letra,numero,fecha,monto) values ('a',1002,curdate(),540);

insert into articulos (codigo,nombre,precio,stock) values (110,'destornillador',30,100);
insert into articulos (codigo,nombre,precio,stock) values (111,'martillo',40*1.21,50);

insert into clientes (nombre,apellido,direccion) values ('Andrea','Abate','Laprida 648');
insert into clientes (apellido,nombre) values ('Stuart','Jhon');
insert into clientes values(null,'Laura','Georgeff','56565','Berutti 2589','');
insert into clientes (codigo,nombre,apellido,cuit,direccion) values (null,'jose','sanchez','xxxxx','chile 150');
insert into clientes values (null,'marta','martinez','xxxxx','florida 150','');
insert into clientes (nombre,apellido,cuit,direccion) values ('carlos','flores','xxxxx','bolivar 150');
insert into clientes values (20,'Romeo','Lopez','34343434','Anchorena 950','');
insert into clientes (nombre,apellido,cuit,direccion) values ('Florencia','Salinas','82828282','W.Morris 3420');
insert into clientes (apellido,nombre,direccion) values ('Ana','Salone',null);

show tables;
describe articulos;
describe clientes;
describe facturas;
select * from articulos;
select * from clientes;
select * from facturas;

-- comando DML select (ANSI)

-- comodin * (todos los campos)
select * from clientes;
select nombre, apellido from clientes;
select apellido, nombre, apellido, curdate() fecha_actual from clientes;
select codigo, concat(nombre,' ',apellido) nombre, cuit, direccion, comentarios 
	from clientes;

-- columna calculada
select letra, numero, fecha, monto, monto*0.21 valor_iva from facturas;
select letra, numero, fecha, monto, round(monto*0.21, 2) valor_iva from facturas;

-- filtrado con where
select * from clientes;
select * from clientes where nombre='Laura';
select * from clientes where codigo=3;

-- Operadores relacionales < <= >= > <> !=
select * from clientes where codigo=6;
select * from clientes where codigo<6;
select * from clientes where codigo<=6;
select * from clientes where codigo>=6;
select * from clientes where codigo>6;
select * from clientes where codigo<>6;
select * from clientes where codigo!=6;

-- Operadores Logicos and or
select * from clientes where nombre='Laura' and apellido='Perez';
select * from clientes where nombre='Laura' or apellido='Perez';
select * from clientes where nombre='Juan' or nombre='Laura';

select * from facturas where monto>=300 and monto<=400;
select * from facturas where monto<300 or monto>400;

-- clausula between, not between
select * from facturas where monto between 300 and 400;
select * from facturas where monto not between 300 and 400;

select * from clientes 
	where codigo=3
    or codigo=5
    or codigo=6
    or codigo=13
    or codigo=15;
    
select * from clientes 
	where codigo!=3
    and codigo!=5
    and codigo!=6
    and codigo!=13
    and codigo!=15;

-- clausula in, not in
select * from clientes where codigo in (3,6,13,15);
select * from clientes where codigo not in (3,6,13,15);

-- valores null
insert into clientes (nombre, apellido, direccion) values
	('Karina','Amanda',null),
    ('Andrea','Moretti','');

select * from clientes where direccion is null;
select * from clientes where direccion is not null;
select * from clientes where direccion=null; -- no funciona

insert into clientes (nombre,apellido) values
	('Mirta','Herrera'),('Marta','Herrera'),
    ('Omar','Herrera'),('Armando','Herrera'),
    ('Monica','Herrera'),('Malena','Herrera'),
    ('Magali','Herrera'),('Melina','Herrera'),
    ('Marcela','Herrera'),('Martin','Herrera'),
    ('Martina','Herrera'),('Mariano','Herrera'),
    ('Mariana','Herrera'),('Carlos','Herrera'),
    ('Miriam','Herrera'),('Marcelo','Herrera');
    
insert into clientes (nombre,apellido) values 
	('Ana','Herrera'),('Jose','Herrera');

-- busqueda de expresiones, like, not like
select * from clientes where nombre not like 'm%';
select * from clientes where nombre like 'm%';
select * from clientes where nombre like 'ma%';
select * from clientes where nombre like 'mar%';
select * from clientes where nombre like 'mari%';
select * from clientes where nombre like '%a';
select * from clientes where nombre like 'm%a';
select * from clientes where nombre like '%ar%';
select * from clientes where nombre like 'm_r%';
select * from clientes where nombre like '___';
select * from clientes where nombre like '____';
select * from clientes where nombre like '_____';
select * from clientes where nombre like '_____%';

-- ordenamiento
select * from clientes;
select * from clientes order by nombre;
select * from clientes order by nombre asc;
select * from clientes order by nombre desc;
select * from clientes order by apellido,nombre;
select * from clientes order by apellido desc,nombre;
select * from facturas order by monto;
select * from facturas order by fecha;





